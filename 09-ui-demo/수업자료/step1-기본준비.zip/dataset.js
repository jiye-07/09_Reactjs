const tabContent = [{
    id: 'newyork',
    subject: 'NewYork',
    content: 'NewYork is the capital city of US.'
}, {
    id: 'london',
    subject: 'London',
    content: 'London is the capital city of England.'
}, {
    id: 'paris',
    subject: 'Paris',
    content: 'Paris is the capital city of France.'
}, {
    id: 'seoul',
    subject: 'Seoul',
    content: 'Seoul is the capital city of Korea.'
}];

const collapseContent = [{
    title: 'Open Collapsible',
    content: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex eacommodo consequat.'
}, {
    title: 'Open Collapsible',
    content: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex eacommodo consequat.'
}, {
    title: 'Open Collapsible',
    content: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex eacommodo consequat.'
}, {
    title: 'Open Collapsible',
    content: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex eacommodo consequat.'
}, {
    title: 'Open Collapsible',
    content: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex eacommodo consequat.'
}];

export { tabContent, collapseContent };